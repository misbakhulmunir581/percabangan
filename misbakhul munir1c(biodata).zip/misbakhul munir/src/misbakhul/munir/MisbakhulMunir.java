/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package misbakhul.munir;

/**
 *
 * @author DD
 */
public class MisbakhulMunir {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
       Long Nik = 3514080103950003l;
       String Nama="MISBAKHUL MUNIR";
       String TTL="pasuruan,01-03-1995";
       String Jeniskelamin="laki-laki";
       String Alamat="jalan brojo";
       String RtRw="005/007";
       String Keldesa="purwosari";
       String Kecamatan="purwosari";
       String Agama="islam";
       String Statusperkawinan="belum menikah";
       String Pekerjaan="pelajar/mahasiswa";
       String Kewarganegaraan="indonesia";
       String Berlaku="seumur hidup";
       String Jurusan="teknnik informatika";
       Long Nim=201969040013l;
       int Angkatan=2019;
       
       System.out.println("NIK = "+Nik);
       System.out.println("Nama = "+Nama);
       System.out.println("Tempat,Tanggal Lahir = "+TTL);
       System.out.println("Jenis Kelamin = "+Jeniskelamin);
       System.out.println("Alamat = "+Alamat);
       System.out.println("Rt/Rw = "+RtRw);
       System.out.println("kelurahan/Desa = "+Keldesa);
       System.out.println("Kecamatan = "+Kecamatan);
       System.out.println("Agama = "+Agama);
       System.out.println("Status perkawianan = "+Statusperkawinan);
       System.out.println("Pekerjaan = "+Pekerjaan);
       System.out.println("Kewarganegaraan = "+Kewarganegaraan);
       System.out.println("Berlaku = "+Berlaku);
       System.out.println("Jurusan = "+Jurusan);
       System.out.println("Nim = "+Nim);
       System.out.println("Angkatan = "+Angkatan);
       
    }
    
}
